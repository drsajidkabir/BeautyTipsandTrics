# HTML Page Sitemap WordPress Plugin
HTML Page Sitemap WordPress Plugin, By [Angelo Mandato](https://angelo.mandato.com).

[HTML Page Sitemap on GitHub](https://github.com/mandato-wordpress/html-sitemap)

[HTML Page Sitemap on WordPress.org](https://wordpress.org/plugins/html-sitemap/)

